package com.yash.lms.daoimpl;

import java.util.List;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.domain.Book;
import com.yash.lms.domain.Employee;
import com.yash.lms.util.Repository;

public class LibrarianDAOImpl implements LibrarianDAO {

	
	
	private List<Book> listOfBooks;

	/** default constructor */
	public LibrarianDAOImpl() {
		listOfBooks = Repository.getRepository().getBooks();
	}

	/**
	 * this method will add the new book into the repository
	 */
	@Override
	public void addNewBook(Book book) {
		listOfBooks.add(book);
	}

	/**
	 * this method will remove the book from the repository
	 */
	@Override
	public void removeBook(long id) {
		for (Book book : listOfBooks) {
			if (book.getId()==id) listOfBooks.remove(book);
		}
	}

	/**
	 * this will provide the list of books
	 */
	@Override
	public List<Book> listBooks() {
		return listOfBooks;
	}
	
	/**
	 * this will search the book according to the provided name 
	 */
	public Book searchBookByName(String bookName) {
		for (Book book : listOfBooks) {
			if (book.getName().equalsIgnoreCase(bookName))
			return book;
		}
		return null;
	}


}
