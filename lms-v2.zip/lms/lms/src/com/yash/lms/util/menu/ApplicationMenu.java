package com.yash.lms.util.menu;

import java.util.List;
import java.util.Scanner;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.daoimpl.LibrarianDAOImpl;
import com.yash.lms.domain.Book;
import com.yash.lms.domain.Librarian;

public class ApplicationMenu {

	private Scanner scanner;
	private Librarian librarian = new Librarian();
	private LibrarianDAO librarianDAO = new LibrarianDAOImpl();
	private static ApplicationMenu applicationMenu=new ApplicationMenu();
	private String option;
	private int choice;
	private String menuChoice;
	private List<Book> listOfBook;

	public void getMenu() {

		scanner = new Scanner(System.in);
		menuChoice = getCredentialMenu();
		do {
			if (menuChoice.equalsIgnoreCase("ok")) {
				getLibrarianMenu();
				choice = scanner.nextInt();
			} else {
				System.out.println(menuChoice);
				System.exit(0);
			}
			switch (choice) {
			case 1:
				System.out.println("Enter book id :");
				long id = scanner.nextLong();
				System.out.println("Enter book name :");
				String name = scanner.next();
				scanner.nextLine();
				System.out.println("Enter author name :");
				String author = scanner.next();
				scanner.nextLine();
				librarianDAO.addNewBook(new Book(id, name, author));
				break;

			case 2:
				listOfBook = librarianDAO.listBooks();
				for (Book book : listOfBook) {
					System.out.println("Title :" + book.getName() + "|| Author :" + book.getAuthor());
				}
				break;

			case 3:
				System.out.println("Enter your book name : ");
				String bookName = scanner.next();
				scanner.nextLine();
				Book book = librarianDAO.searchBookByName(bookName);
				System.out.println(book.getName() + " || " + book.getAuthor());
				break;

			case 4:
				System.out.println("Enter book id: ");
				long bookId = scanner.nextLong();
				librarianDAO.removeBook(bookId);
				break;
			case 5:
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue ? Y/N");
			option = scanner.next();
		} while (option.equalsIgnoreCase("Y"));
	}

	/**
	 * this will provide the librarian menu.
	 */
	private void getLibrarianMenu() {
		System.out.println("***********Menu***************");
		System.out.println("1. Add Book");
		System.out.println("2. List Books");
		System.out.println("3. Search Books");
		System.out.println("4. Remove Book");
		System.out.println("5. Exit");
		System.out.println("Enter Your Choice..!");
	}

	/**
	 * this will provide the credential menu
	 * 
	 * @return ok if credential are correct else will return wrong Credential
	 */
	private String getCredentialMenu() {
		System.out.println("***********WELCOME TO LIS***************");
		System.out.println("1. Enter Username: ");
		String username = scanner.next();
		scanner.nextLine();
		System.out.println("2. Enter Password: ");
		String password = scanner.nextLine();
		String result = librarian.checkCredential(username);
		if (result.equalsIgnoreCase("ok"))
			return "ok";
		return "Wrong Credential";
	}
	
	public static ApplicationMenu getApplicationMenu() {
		return applicationMenu;
	}

}
