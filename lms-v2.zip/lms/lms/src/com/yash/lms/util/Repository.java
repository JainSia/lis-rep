package com.yash.lms.util;

import java.util.ArrayList;
import java.util.List;

import com.yash.lms.domain.Book;
import com.yash.lms.domain.Employee;
import com.yash.lms.domain.Librarian;
/**
 * this class will work as a repository for employee and book both.
 * 
 * @author saloni.jain
 *
 */
public class Repository {
	
	/**
	 * repositiry of books
	 */
	private List<Book> books=new ArrayList();
	/**
	 * repository of employees
	 */
	private List<Employee> employees=new ArrayList();
	
	private static Repository repository=new Repository();
	
	public Repository() {
	
		/** this will initialize user repository*/
		employees.add(new Librarian(1, "soumya", "librarian"));

		/** this will initialize book repository*/
		books.add(new Book(101, "Headfirst", "Bert Bates"));
		books.add(new Book(102, "CleanCode", "Robert C. Martin"));
		books.add(new Book(103, "SCJP", "Kathy Sierra"));		
	}

	/**getters*/
	public List<Book> getBooks() {
		return books;
	}
	
	public List<Employee> getUsers() {
		return employees;

	}
	
	public static Repository getRepository() {
		return repository;
	}
	
}
