package com.yash.lms.domain;
/**
 * this class will act as a data traveller for book. 
 * 
 * @author saloni.jain
 *
 */
public class Book {

	private long id;
	private String name;
	private String author;
	
	/**parameterized constructor*/
	public Book(long id, String name, String author) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
	}
	
	
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + "]";
	}
	
	/**getters*/
	
	public String getName() {
		return this.name;
	}
	public long getId() {
		return id;
	}
	public String getAuthor() {
		return author;
	}
	 
	

	
}
