package com.yash.lms.domain;

import java.util.List;

import com.yash.lms.util.Repository;

public class Librarian extends Employee {
	
	private List<Employee> listOfUsers;
	
	public Librarian() {
	}
	
	/** parameterized constructor*/
	public Librarian(long id, String name, String role) {
		super(id, name, role);
	}

	@Override
	public void accessingSystem() {
	}

	public String checkCredential(String username) {
		listOfUsers = Repository.getRepository().getUsers();
		System.out.println(listOfUsers);
		for (Employee user : listOfUsers) {
			if (user.getName().equalsIgnoreCase(username)) {
				return "ok";
			}
		}
		return "Wrong Credential";
	}
}
