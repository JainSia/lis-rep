package com.yash.lms.main;

import com.yash.lms.util.menu.ApplicationMenu;

public class App {

	public static void main(String[] args) {
		ApplicationMenu.getApplicationMenu().getMenu();
		}
}
