package com.yash.lms.dao;

import java.util.List;

import com.yash.lms.domain.Book;
/**
 * this interface will provide the functionality to librarian regarding books 
 * example: addNewBook , removeBook, listBook, searchBookByName etc.
 * @author saloni.jain
 *
 */
public interface LibrarianDAO {

	public void addNewBook(Book book);
	
	public void removeBook(long id);
	
	public List<Book> listBooks();

	public Book searchBookByName(String bookName);

}
