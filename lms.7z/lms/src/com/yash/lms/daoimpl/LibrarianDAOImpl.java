package com.yash.lms.daoimpl;

import java.util.List;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.domain.Book;
import com.yash.lms.domain.Employee;
import com.yash.lms.util.Repository;

public class LibrarianDAOImpl implements LibrarianDAO {

	Repository repository = new Repository();
	List<Book> listOfBooks;
	List<Employee> listOfUsers;

	public LibrarianDAOImpl() {
		listOfBooks = repository.getBooks();
		listOfUsers = repository.getUsers();
	}

	@Override
	public void addNewBook(Book book) {

		listOfBooks.add(book);
		System.out.println(listOfBooks);
	}

	@Override
	public void removeBook(long id) {
		listOfBooks.remove(id);
		System.out.println(listOfBooks);

	}

	@Override
	public List<Book> listBooks() {
		return listOfBooks;
	}

	public Book searchBookByName(String bookName) {
		for (Book book : listOfBooks) {
			if (book.getName().equalsIgnoreCase(bookName))
			return book;
		}
		return null;
	}

	public String Login(String username) {

		for (Employee user : listOfUsers) {
			if (user.getName().equalsIgnoreCase(username)) {
				return "ok";
			}
		}
		return "Wrong Credential";
	}
}
