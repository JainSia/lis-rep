package com.yash.lms.util;

import java.util.ArrayList;
import java.util.List;

import com.yash.lms.domain.Book;
import com.yash.lms.domain.Employee;
import com.yash.lms.domain.Librarian;
import com.yash.lms.domain.User;

public class Repository {

	private List<Book> books=new ArrayList();
	private List<Employee> users=new ArrayList();
	
	public Repository() {
	
		/** this will initialize user repository*/
		users.add(new Librarian(1, "soumya", "librarian"));
		users.add(new User(2, "manas", "user"));
		
		/** this will initialize book repository*/
		books.add(new Book(101, "Headfirst", "Bert Bates"));
		books.add(new Book(102, "CleanCode", "Robert C. Martin"));
		books.add(new Book(103, "SCJP", "Kathy Sierra"));
		
	}
	
	
	
	public void setBooks(List<Book> books) {
		this.books = books;
	}



	public void setUsers(List<Employee> users) {
		this.users = users;
	}



	public List<Book> getBooks() {
		return books;
	}
	
	public List<Employee> getUsers() {
		return users;

	}
	
	
	
}
