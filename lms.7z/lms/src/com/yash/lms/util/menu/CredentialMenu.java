package com.yash.lms.util.menu;

import java.util.Scanner;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.daoimpl.LibrarianDAOImpl;

public class CredentialMenu {
	private static Scanner scanner = new Scanner(System.in);
	private static LibrarianDAO librarianDAO = new LibrarianDAOImpl();
	private static LibrarianMenu librarianMenu = new LibrarianMenu();
	private int choice;

	public int getCredentialMenu() {

		System.out.println("1. Enter Username: ");

		String username = scanner.next();
		scanner.nextLine();

		System.out.println("2. Enter Password: ");
		String password = scanner.nextLine();
		String result = librarianDAO.Login(username);

		if (result.equalsIgnoreCase("ok"))
			choice = librarianMenu.getLibrarianMenu();
		return choice;

	}
}
