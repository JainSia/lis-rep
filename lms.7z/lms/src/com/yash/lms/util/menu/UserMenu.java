package com.yash.lms.util.menu;

public class UserMenu {
	
	public void getUserMenu() {
		System.out.println("***********Welcome To Library Information System***************");
		System.out.println("1. Enter your Credentials ?");
		System.out.println("2. List Books");
		System.out.println("3. Search Books");
		System.out.println("4. Exit");

		System.out.println("Enter Your Choice..");

	}
}
