package com.yash.lms.util.menu;

import java.util.List;
import java.util.Scanner;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.daoimpl.LibrarianDAOImpl;
import com.yash.lms.domain.Book;


public class LibrarianMenu {
	private  Scanner scanner;
	private  LibrarianDAO librarianDAO = new LibrarianDAOImpl();
	private 	List<Book> listOfBook;
	private  CredentialMenu credentialMenu = new CredentialMenu();
	private  UserMenu userMenu = new UserMenu();


	public int getLibrarianMenu() {
		System.out.println("***********Menu***************");
		System.out.println("1. Add Book");
		System.out.println("2. List Books");
		System.out.println("3. Search Books");
		System.out.println("4. Remove Book");
		System.out.println("5. Exit");
		System.out.println("Enter Your Choice..!");
		int option=scanner.nextInt();
		return option;
	}

	public void perfromLibrarianFunction(int menuChoice){
		scanner = new Scanner(System.in);
	
		if(menuChoice==1 ){
			System.out.println("Enter book id :");
			long id = scanner.nextLong();
			System.out.println("Enter book name :");
			String bookName = scanner.next();
			scanner.nextLine();
			System.out.println("Enter author name :");
			String author = scanner.next();
			scanner.nextLine();
			librarianDAO.addNewBook(new Book(id, bookName, author));
		}else if ( menuChoice==4){
			System.out.println("Enter book Id: ");
			long bookId = scanner.nextLong();
			librarianDAO.removeBook(bookId);
		}else if(menuChoice==2){
			listOfBook = librarianDAO.listBooks();
			for (Book book : listOfBook) {
				System.out.println("Title :" + book.getName() + "|| Author :" + book.getAuthor());
			}
			
		}else if(menuChoice==3){
			System.out.println("Enter your book name : ");
			String bookName = scanner.next();
			scanner.nextLine();
			Book book = librarianDAO.searchBookByName(bookName);
			System.out.println(book.getName() + " || " + book.getAuthor());
		}else{
			System.exit(0);
		}
			
			
		}
	
}
