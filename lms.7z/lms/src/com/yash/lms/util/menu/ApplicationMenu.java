package com.yash.lms.util.menu;

import java.util.List;
import java.util.Scanner;

import com.yash.lms.dao.LibrarianDAO;
import com.yash.lms.daoimpl.LibrarianDAOImpl;
import com.yash.lms.domain.Book;

public class ApplicationMenu {

	private static Scanner scanner;
	private static LibrarianDAO librarianDAO = new LibrarianDAOImpl();

	private static CredentialMenu credentialMenu = new CredentialMenu();
	private static UserMenu userMenu = new UserMenu();
	private static LibrarianMenu librarianMenu=new LibrarianMenu();
	private static String option;
	public static void getMenu() {
		
		List<Book> listOfBook;

		do {
			userMenu.getUserMenu();
			scanner = new Scanner(System.in);
			int Choice = scanner.nextInt();
			switch (Choice) {
			
			case 1:
				int menuChoice = credentialMenu.getCredentialMenu();
				librarianMenu.perfromLibrarianFunction(menuChoice);
					
				break;

			case 2:
				listOfBook = librarianDAO.listBooks();
				for (Book book : listOfBook) {
					System.out.println("Title :" + book.getName() + "|| Author :" + book.getAuthor());
				}
				break;

			case 3:
				System.out.println("Enter your book name : ");
				String bookName = scanner.next();
				scanner.nextLine();
				Book book = librarianDAO.searchBookByName(bookName);
				System.out.println(book.getName() + " || " + book.getAuthor());
				break;

			case 4:
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue ? Y/N");
			option = scanner.next();
		}while(option.equalsIgnoreCase("Y"));
}

}
