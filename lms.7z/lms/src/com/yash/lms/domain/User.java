package com.yash.lms.domain;

public class User extends Employee {

	public User(long id, String name, String role) {
		super(id, name, role);
	}

	@Override
	public void accessingSystem() {
		
	}

}
