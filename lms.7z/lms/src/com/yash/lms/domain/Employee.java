package com.yash.lms.domain;

public abstract class Employee {
	private long id;
	private String name;
	private String role;

	public Employee(long id, String name, String role) {
		super();
		this.id = id;
		this.name = name;
		this.role = role;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", role=" + role + "]";
	}

	public String getName() {
		return name;
	}
	public abstract void accessingSystem();
}
