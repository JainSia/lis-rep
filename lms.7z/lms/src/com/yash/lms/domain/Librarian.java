package com.yash.lms.domain;

public class Librarian extends Employee{

	public Librarian(long id, String name, String role) {
		super(id, name, role);
	}

	@Override
	public void accessingSystem() {
		
	}

}
