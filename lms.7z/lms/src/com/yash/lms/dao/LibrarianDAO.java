package com.yash.lms.dao;

import java.util.List;

import com.yash.lms.domain.Book;

public interface LibrarianDAO {

	public void addNewBook(Book book);
	
	public void removeBook(long id);
	
	public List<Book> listBooks();

	public Book searchBookByName(String bookName);

	public String Login(String username);
}
